#include <stdio.h>

int main(){

    int i,n;

    for(i = 0; i <= 10; i++) {
        
        n = 0;
        n = (i * 7);
        printf("7 x %d = %d \n",i,n);
        
    }

    return 0;
}
